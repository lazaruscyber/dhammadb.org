---
title: Pārājika
categories: [Monastic rules, Vinaya Piṭaka]
summary: The four pārājika rules are the gravest offences in the Vinaya; a monk who commits one is defeated and is no longer a monk.
---

:::infobox Pārājika
Pāli: {{term|Pārājika}}
Meaning: Defeat
:::

The **pārājika** ({{lang|Pāli|pārājika}}) rules are the four gravest offences of the monastic discipline. A monk who commits one is "defeated": he is no longer a bhikkhu and can never again be ordained in this life.[^vin]

## The four rules

| No. | Offence |
|---|---|
| 1 | Sexual intercourse |
| 2 | Taking, with intent to steal, what is not given, of a value that would lead a king to punish |
| 3 | Intentionally depriving a human being of life, or inciting someone to die |
| 4 | Falsely claiming a superhuman state, such as jhāna or a noble attainment |

## Origins

Each rule was laid down in response to a particular incident. The first was laid down after the monk Sudinna, at his family's urging, had intercourse with his former wife to provide an heir. The third was laid down after the incident of monks who took their own lives after misunderstanding the contemplation of foulness ([[Asubha]]). The fourth followed monks during a famine who praised each other's attainments to gain alms.[^vin]

## The simile

The Vinaya compares a defeated monk to a man whose head is cut off, a withered leaf fallen from its stalk, a broken flat stone, and a palm tree with its crown cut off: none can be restored.[^vin]

The bhikkhunīs have eight pārājika rules.

[^vin]: Vinaya Piṭaka, *Suttavibhaṅga*, Pārājikakaṇḍa.

:::navbox Monastic life
Ordination: [[Pabbajjā]] | [[Upasampadā]] | [[Sāmaṇera]] | [[Bhikkhu]] | [[Bhikkhunī]]
Discipline: [[Pātimokkha]] | [[Pārājika]] | [[Saṅghādisesa]] | [[Sīmā]]
The year: [[Vassa]] | [[Pavāraṇā]] | [[Kathina]] | [[Uposatha]]
Practice: [[Dhutaṅga]] | [[Requisites]]
:::
